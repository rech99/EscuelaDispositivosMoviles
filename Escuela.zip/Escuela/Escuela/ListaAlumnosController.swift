//
//  ViewController.swift
//  Escuela
//
//  Created by Alumno on 10/7/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListaAlumnosController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaAlumno") as! CeldaAlumnoController
        celda.lblNombre.text = alumnos[indexPath.row].nombre
        celda.lblCarrera.text = alumnos[indexPath.row].carrera
        celda.lblMat.text = alumnos[indexPath.row].matricula
        return celda
    }
    
    
    
    
    
    var alumnos : [Alumno] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Alumnos"
        
        alumnos.append(Alumno(nombre: "Pedro Perez", matricula: "189143", correo:"pedro@hotmail.com", celular:"6645234312", carrera : "IPM"))
        alumnos.append(Alumno(nombre: "Gustavo Fring", matricula: "189453", correo:"gustavo@hotmail.com", celular:"6645234312", carrera: "Mercadotecnia"))
        alumnos.append(Alumno(nombre: "Rafa Portillo", matricula: "189193", correo:"elrafas@hotmail.com", celular:"6342234312", carrera: "Negocios"))
        
    
    }


}

